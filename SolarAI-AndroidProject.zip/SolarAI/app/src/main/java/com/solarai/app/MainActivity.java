package com.solarai.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {

    private WebView webView;
    private static final String TAG = "SolarAI";
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);

        // ── JavaScript Bridge ──────────────────────────────────────────────
        // แทนที่ fetch() → ให้ Android เรียก Anthropic API แทน (ไม่มี CORS)
        webView.addJavascriptInterface(new AnthropicBridge(), "AndroidBridge");

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());

        // โหลด HTML จาก assets
        webView.loadUrl("file:///android_asset/index.html");
    }

    // ── Bridge Class ───────────────────────────────────────────────────────
    class AnthropicBridge {

        // บันทึก API Key ใน SharedPreferences
        @JavascriptInterface
        public void saveApiKey(String key) {
            SharedPreferences prefs = getSharedPreferences("solar_prefs", MODE_PRIVATE);
            prefs.edit().putString("api_key", key).apply();
        }

        // ดึง API Key
        @JavascriptInterface
        public String getApiKey() {
            SharedPreferences prefs = getSharedPreferences("solar_prefs", MODE_PRIVATE);
            return prefs.getString("api_key", "");
        }

        // เรียก Anthropic API จาก Native (ไม่มี CORS!)
        // callbackId ใช้คืนผลกลับไปยัง JavaScript
        @JavascriptInterface
        public void callClaude(String jsonBody, String apiKey, String callbackId) {
            new Thread(() -> {
                String result;
                try {
                    URL url = new URL("https://api.anthropic.com/v1/messages");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setRequestProperty("x-api-key", apiKey);
                    conn.setRequestProperty("anthropic-version", "2023-06-01");
                    conn.setDoOutput(true);
                    conn.setConnectTimeout(30000);
                    conn.setReadTimeout(60000);

                    // ส่ง request body
                    byte[] bodyBytes = jsonBody.getBytes(StandardCharsets.UTF_8);
                    OutputStream os = conn.getOutputStream();
                    os.write(bodyBytes);
                    os.close();

                    // อ่าน response
                    int statusCode = conn.getResponseCode();
                    BufferedReader reader;
                    if (statusCode >= 200 && statusCode < 300) {
                        reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                    } else {
                        reader = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8));
                    }

                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) sb.append(line);
                    reader.close();
                    conn.disconnect();

                    result = sb.toString();
                } catch (Exception e) {
                    result = "{\"error\":{\"message\":\"" + e.getMessage().replace("\"", "'") + "\"}}";
                    Log.e(TAG, "API Error: " + e.getMessage());
                }

                // คืนผลกลับ JavaScript บน Main Thread
                final String finalResult = result;
                mainHandler.post(() -> {
                    String escaped = finalResult
                        .replace("\\", "\\\\")
                        .replace("'", "\\'")
                        .replace("\n", "\\n")
                        .replace("\r", "");
                    webView.evaluateJavascript(
                        "window._claudeCallback('" + callbackId + "', '" + escaped + "')",
                        null
                    );
                });
            }).start();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
