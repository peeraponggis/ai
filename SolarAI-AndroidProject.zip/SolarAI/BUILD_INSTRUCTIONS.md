# วิธี Build APK จาก Project นี้

## ทางที่ 1: Android Studio (แนะนำ — ง่ายที่สุด)

1. ดาวน์โหลด Android Studio: https://developer.android.com/studio
2. เปิดโฟลเดอร์ `SolarAI` นี้ใน Android Studio
3. รอ Gradle sync (ครั้งแรกใช้เวลา 5-10 นาที)
4. เมนู **Build → Build APK(s)**
5. APK อยู่ที่: `app/build/outputs/apk/debug/app-debug.apk`
6. โอน APK ไปติดตั้งบน tablet

## ทางที่ 2: Build บน GitHub Actions (ไม่ต้องติดตั้งอะไร)

1. สร้าง GitHub repo ใหม่
2. อัพโหลดโฟลเดอร์ `SolarAI` ทั้งหมด
3. สร้างไฟล์ `.github/workflows/build.yml`:

```yaml
name: Build APK
on: [push]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-java@v3
        with:
          java-version: '17'
          distribution: 'temurin'
      - name: Build APK
        run: |
          cd SolarAI
          chmod +x gradlew
          ./gradlew assembleDebug
      - uses: actions/upload-artifact@v3
        with:
          name: solar-ai-apk
          path: SolarAI/app/build/outputs/apk/debug/app-debug.apk
```

4. Push โค้ด → GitHub Actions จะ build APK อัตโนมัติ
5. ดาวน์โหลด APK จาก Actions tab

## ทำไม APK นี้ถึงเรียก Anthropic API ได้?

Android WebView ใช้ Java HttpURLConnection ซึ่ง:
- ✅ ไม่มี CORS restriction (CORS เป็นแค่ browser policy)
- ✅ เรียก api.anthropic.com ได้โดยตรง
- ✅ API Key เก็บใน Android SharedPreferences (ปลอดภัย)
- ✅ JavaScript ↔ Java ผ่าน AndroidBridge interface
